Esfera.h contiene el array de v�rtices con el que se forma la espera.
Shader.frag, shader.vert vertex shader y fragment shader pueden ser modificados.

